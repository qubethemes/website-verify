<?php
/**
 * Fired when the plugin is installed.
 * This class defines all code necessary to run during the plugin's activation.
 * @link              https://qubethemes.com/
 * @since             1.0.0
 * @package           Website-Verify
 * @subpackage        Website-Verify/includes
 */


class Website_Verify_Activator {

/**
 * Short Description. (use period)
 *
 * Long Description.
 *
 * @since    1.0.0
 */
public static function activate() {

}

}
