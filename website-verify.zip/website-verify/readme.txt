=== Website Verify ===
Contributors: qubethemes
Tags: verify, website verify, search engine  verify
Requires at least: 4.7
Tested up to: 5.8
Stable tag: 1.0.0
License: GPLv3 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Add verification code to verify your website using Google & Other Search Engines

== Description ==

Add verification code to verify your website using Google & Other Search Engines


== Installation ==

1. Install the plugin either via the WordPress.org plugin directory, or by uploading the files to your server (in the /wp-content/plugins/ directory).
2. Activate the Mantra Audience plugin through the 'Plugins' menu in WordPress.


== Changelog ==

= 1.0.0 | 2021/08/22 =
* Initial release
